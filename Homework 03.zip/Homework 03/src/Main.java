public class Main {
    public static void main(String[] args) {
        System.out.println("Buch Max von Baron");
        System.out.println("Age 25");
        System.out.println("Height 178");
        System.out.println();
        System.out.println("Rein Abram von Heiko");
        System.out.println("Age 32");
        System.out.println("Height 154");
        System.out.println();
        System.out.println("Heiko Steel von Beruf");
        System.out.println("Age 52");
        System.out.println("Height 171");
        System.out.println();
        System.out.println();
        System.out.printf("%.2f, %.2f, %.2f", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.print(" ");
        System.out.print("-");
        System.out.print("-");
        System.out.println("-");
        System.out.print("I");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.println("I");
        System.out.print(" ");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");


    }
}